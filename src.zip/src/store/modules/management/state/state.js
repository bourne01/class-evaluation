export default {
    majStudentList:[],//专业里的学生列表
    studentList:[],//学生列表
    total:0,//总共数据条数
    curPage:1,//当前页码
    pageSize:10,//每页多少条数据
    stuSearch:{},//赛选学生的条件对象
    curStudent:{},//当前选中的学生
}