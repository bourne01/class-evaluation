/**************************************************************************************************************
 * 招生录取管理
 *************************************************************************************************************/
export const SET_MAJOR_STUDENT_LIST = 'SET_MAJOR_STUDENT_LIST'
export const SET_STUDENT_LIST = 'SET_STUDENT_LIST' 
export const SET_TOTAL = 'SET_TOTAL'
export const SET_SEARCH_PARAMS = 'SET_SEARCH_PARAMS'
