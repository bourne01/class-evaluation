<template>
    <div class="no-data">
        <slot></slot>
    </div>
</template>

<style scoped>
    .no-data{
        text-align:center;
        color:#9ea2a2;
    }
</style>

