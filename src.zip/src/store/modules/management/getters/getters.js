export default {
    getStateVals(state){
        return `${state.state1} ${state.state2} ${state.state3}`
    }
}