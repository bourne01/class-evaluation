export default [    
    {
        path:'/admin',
        name:'Admin',
        component:() => import('../../views/admin/home/home.vue'),
        children:[
            {
                path:'main',
                name:'Main',
                component:() => import('../../views/admin/home/main.vue'),
            }, 
            {
                path:'evaluation',
                name:'procedure-evalualtion',
                component:() => import('../../views/admin/home/evaluation.vue'),
            }, 
            {
                path:'',
                redirect:'main'
            }

        ],
        
    },   
    /* {
        path:'/admin-icon',
        name:'AdminIcon',
        component:() => import('../../views/admin/home/home-icon.vue'),
        children:[
            {
                path:'main',
                name:'Main',
                component:() => import('../../views/admin/home/main.vue'),
            },
            {
                path:'',
                redirect:'main',
            }            
        ]
    },  */
    
        
]