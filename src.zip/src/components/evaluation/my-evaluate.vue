<template>
      <div class="evaluate">
            <div class="check-work" id="work">
                <h3>考勤</h3>
                <ul>
                    <li>请假</li>
                    <li>旷课</li>
                    <li>迟到</li>
                </ul>
            </div>
             <div class="check-work">
                <h3>负向指标</h3>
                <ul>
                    <li>睡觉</li>
                    <li>玩手机</li>
                    <li class="eat">吃零食</li>
                    <li>其他</li>
                    <li>玩手机</li>
                </ul>
            </div>
            <div class="check-work">
                <h3>正向指标</h3>
                <ul>
                    <li>睡觉</li>
                    <li>玩手机</li>
                    <li class="eat">吃零食</li>
                    <li>其他</li>
                    <li>玩手机</li>
                </ul>
            </div>
            <div class="check-work" id="evaluate">
                <h3>课程整体评价</h3>
                 <i></i>
                 <i></i>
                 <i></i>
            </div>
      </div>
</template>

<script>

export default {
    components:{

    }
}
</script>

<style scoped>
     *{
         padding: 0px;
         margin: 0px;
     }
     .evaluate{
         width: 900px;
         height: 627px;
         background-color: white;
         border-bottom-right-radius: 10px;
     }
     #work{
         padding-top: 60px;
     }
     .check-work{
         width: 800px;
         height: 68px;
         margin-left: 50px;
         margin-bottom: 56px;
     }
     h3{
         font-size: 18px;
     }
     ul{
         margin-top: 20px;
     }
     ul li{
         float: left;
         width: 70px;
         height: 30px;
         background-color: #f3f3f6;
         border-radius: 2px;
         text-align: center;
         line-height: 30px;
         margin-right: 30px;
         color: #939aad;
     }
     .eat{
         background-color: #ffe8e0;
         color: #fc6835;
     }
     .check-work i{
         display: block;
         width: 22px;
         height: 22px;
         background-image: url(../../assets/svg/favorite-active.svg);
         float: left;
         margin-right: 30px;
         margin-top: 30px;
     }
     #evaluate{
         margin-bottom: 0;
     }
</style>